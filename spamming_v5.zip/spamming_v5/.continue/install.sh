echo  "\033[37;1m
 
 \033[37;1m+-+-+-+-+-+-+-+
 \033[37;1m|\033[32;1mI|n|s|t|a|l|l\033[37;1m|
\033[37;1m +-+-+-+-+-+-+-+ "
echo  "\033[35;1m                    กำลังตติดตั้งแพคเกจ"    

echo  "\033[0m"
pkg  update
pkg  upgrade
pkg install irssi
pkg install figlet
pip install figlet
pip install requests
pip install colorama
pip install toilet
pip install lolcat
gem install lolcat
pkg install ruby 
echo  ""
echo  "\033[37;1m  - --  - - ---  - [\033[37;1m  \033[32;1m✔️  \033[37;1m]  - --  - - ---  -    \033[32;1mติดตั้งสำเร็จ"
echo  ""
sleep 3
clear
python .login1